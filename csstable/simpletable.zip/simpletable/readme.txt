
------------------------------------------------------------
This resource has been created by Devin Price of WPTheming.com
http://wptheming.com/2011/01/simple-table-css3/
------------------------------------------------------------

It is based on Orman Clarke's Simple Little Table design:
http://www.premiumpixels.com/simple-little-table-psd/

--

TERMS OF USE:

This Simple Table code is free for use in both personal and commercial projects.

You may freely use the resource, without restriction, in software programs, web templates and other materials intended for sale or distribution. No attribution or backlinks are required, but any form of spreading the word is always appreciated!